package wilptt.dpallagolla.com.wilptimetable.Listeners;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by dpallagolla on 10/2/2017.
 */

public class CustomOnItemSelectedListener implements AdapterView.OnItemSelectedListener  {

    Context context;
    Activity activity;
    ProgressDialog  progressDialog;
    String link = "https://wilptt-181505.appspot.com/?show=";
    CustomOnItemSelectedListener(Activity a) throws MalformedURLException {
        this.context = a.getApplicationContext();
        this.activity = a;
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(parent.getContext(),
                "OnItemSelectedListener : " + parent.getItemAtPosition(position).toString(),
                Toast.LENGTH_SHORT).show();
        String sCode = (String) parent.getItemAtPosition(position);
        if(sCode !="SELECT COURSE CODE") {
//            ConnectivityManager check = (ConnectivityManager) this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
//            NetworkInfo[] info = check.getAllNetworkInfo();
//            for (int i = 0; i<info.length; i++){
//                if (info[i].getState() == NetworkInfo.State.CONNECTED){
//                    Toast.makeText(context, "Internet is connected",
//                            Toast.LENGTH_SHORT).show();
//                }
//            }

            link = link+sCode;

            try {

                Log.i("subjectCode:",sCode);
//                progressDialog = ProgressDialog.show(this.activity.getApplicationContext(), "", "Fetching data",true);

                URL url = new URL(link);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.connect();
                InputStream is = conn.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
                String webPage = "",data="";

                while ((data = reader.readLine()) != null){
                    webPage += data + "\n";
                }
//                TextView t = (TextView) activity.findViewById(R.id.textView);
//                t.setText((webPage));
//                progressDialog.dismiss();
            } catch (Exception e) {
                //progressDialog.dismiss();
                e.printStackTrace();
            }


        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}
