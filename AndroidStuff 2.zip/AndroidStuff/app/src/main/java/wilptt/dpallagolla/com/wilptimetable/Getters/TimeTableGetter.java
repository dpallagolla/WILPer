package wilptt.dpallagolla.com.wilptimetable.Getters;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import wilptt.dpallagolla.com.wilptimetable.Activities.DrawerActivity;
import wilptt.dpallagolla.com.wilptimetable.Activities.MainActivity;
import wilptt.dpallagolla.com.wilptimetable.Fragments.myListFragment;
import wilptt.dpallagolla.com.wilptimetable.R;

/**
 * Created by dpallagolla on 10/7/2017.
 */

public class TimeTableGetter extends AsyncTask<String, Void, String> {

    Activity activity;
//    LinearLayout ll;
    ProgressDialog progressDialog;
    public TimeTableGetter(Activity a) {
        activity = a;
//        ll = (LinearLayout) a.findViewById(R.id.progressLayout);
    }

    @Override
    protected void onPreExecute() {

//        activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
//                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

        progressDialog = new ProgressDialog(activity);

        progressDialog.setMessage("Fetching data");

        progressDialog.setCancelable(false);

        progressDialog.show();
//        ll.setVisibility(View.VISIBLE);

    }

    @Override
    protected String doInBackground(String... params) {
        String webPage = "",data = "";
        try {
            String link = params[0];
            URL url = new URL(link);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.connect();
            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            webPage = "";
            data = "";

            while ((data = reader.readLine()) != null) {
                webPage += data + "\n";
            }

        }
        catch (Exception e) {
            e.printStackTrace();
        }

        if(DrawerActivity.bisMockDataEnabled) {
            webPage = "[{\"courseCode\":\"COURSECODE1\",\"time\":\"10:00-12:00 AM\",\"day\":\"SomeDay\",\"subjectString\":\"THISISA/TEST/COURSE/TEXT\"},{\"courseCode\":\"COURSECODE2\",\"time\":\"10:00-12:00 AM\",\"day\":\"SomeDay\",\"subjectString\":\"THISISA/TEST/COURSE/TEXT\"},{\"courseCode\":\"COURSECODE3\",\"time\":\"10:00-12:00 AM\",\"day\":\"SomeDay\",\"subjectString\":\"THISISA/TEST/COURSE/TEXT\"},{\"courseCode\":\"COURSECODE4\",\"time\":\"10:00-12:00 AM\",\"day\":\"SomeDay\",\"subjectString\":\"THISISA/TEST/COURSE/TEXT\"},{\"courseCode\":\"COURSECODE5\",\"time\":\"10:00-12:00 AM\",\"day\":\"SomeDay\",\"subjectString\":\"THISISA/TEST/COURSE/TEXT\"}]";
        }

        return webPage;
    }

    @Override
    protected void onPostExecute(String result) {

//        ll.setVisibility(View.GONE);


        Bundle arguments = new Bundle();
        arguments.putString("response", result);

        myListFragment list = new myListFragment();

        list.setArguments(arguments);

        FragmentManager fragmentManager = activity.getFragmentManager();

        if(fragmentManager.findFragmentById(R.id.listFragment)!=null) {

            fragmentManager.beginTransaction().remove(fragmentManager.findFragmentById(R.id.listFragment)).commit();

        }
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();


        fragmentTransaction.add(R.id.listFragment, list, "something");

        fragmentTransaction.commit();

//        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

        progressDialog.dismiss();



    }


}

