package wilptt.dpallagolla.com.wilptimetable.Fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.HashMap;

import wilptt.dpallagolla.com.wilptimetable.Adapters.WhatsAppAdapter;
import wilptt.dpallagolla.com.wilptimetable.R;

/**
 * Created by deadpool on 19/12/17.
 */

public class whatsAppFragment extends ListFragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_whatsapp, container, false);

//        AdRequest request = new AdRequest.Builder()
//                .addTestDevice("33BE2250B43518CCDA7DE426D04EE232")
//                .build();
        AdRequest request = new AdRequest.Builder()
                .build();
        AdView adView = (AdView) view.findViewById(R.id.adView);
        adView.loadAd(request);

        //ArrayList thats going to hold the search results
        final ArrayList<HashMap<String, Object>> searchResults;

        //ArrayList that will hold the original Data
        final ArrayList<HashMap<String, Object>> originalValues;
        LayoutInflater lInflater;

        final EditText searchBox= view.findViewById(R.id.searchBox);
        ListView playerListView= view.findViewById(android.R.id.list);

        //get the LayoutInflater for inflating the customomView
        //this will be used in the custom adapter
        lInflater=(LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        //these arrays are just the data that
        //I'll be using to populate the ArrayList
        //You can use our own methods to get the data
        String names[]={
                "4th SEM Project discussion",
                "Advanced Computer Networks",
                "Advanced Data Mining",
                "Artificial Intelligence",
                "Cloud Computing",
                "Computer Graphics",
                "Computer Networks",
                "Data Mining",
                "Data Storage Technologies & Networks Group#01",
                "Data Storage Technologies & Networks Group#02",
                "Data Warehousing",
                "Distributed Computing  Group#01",
                "Distributed Computing  Group#02",
                "Distributed Computing Group#3",
                "Distributed Data Systems Group#1",
                "Distributed Data Systems: Group#2",
                "Embedded System Design",
                "Hardware Software Co-Design",
                "Information Retrieval",
                "Internetworking Technologies",
                "Machine Learning",
                "Multimedia computing",
                "MTech Dissertation",
                "Network embedded Application",
                "Network Programming",
                "Network Security",
                "Pervasive Computing",
                "Real Time Operating Systems",
                "Software Development Portable Devices  Group#01",
                "Software Development Portable Devices  Group#02",
                "Software For Embedded Systems",
                "Software Project Management",
                "Software Quality Management",
                "Software Testing Methodologies",
                "Telecom Network Management",
                "Usability Engineering",
                "BITS WILP - Leisure"
        };

        String teams[]={
                "https://chat.whatsapp.com/EcaAoiZfBFrBukhh94O996",
                "https://chat.whatsapp.com/5YsCltWVqL78oDPsWpXBcl",
                "https://chat.whatsapp.com/JsydiJ1WPvELFxVHjNMwDW",
                "https://chat.whatsapp.com/IKmopGo9AVrIHCZORAvj9Z",
                "https://chat.whatsapp.com/1nxKwf4dBYN0Btd4Cu6h2R",
                "https://chat.whatsapp.com/801nc5o2JbBB9tc1EUHaxe",
                "https://chat.whatsapp.com/04JWYfkawMSHvWQwmcdQpW",
                "https://chat.whatsapp.com/LsNFuotQkok4wzssXTNkg8",
                "https://chat.whatsapp.com/HBUp3q4KxJeKxa3vDIE167",
                "https://chat.whatsapp.com/DXHV5IdFhasKwqYgxcD07H",
                "https://chat.whatsapp.com/6vPFrpoVXfa4J7FYPjSCm8",
                "https://chat.whatsapp.com/AT7by0N71bpDo2SZkUnHb6",
                "https://chat.whatsapp.com/B3vPMqKMCElA2GA8G9od1e",
                "https://chat.whatsapp.com/DXTG2GreQU65hOwduOlHsb",
                "https://chat.whatsapp.com/0qlxVCYauzRCPudYS3DYT0",
                "https://chat.whatsapp.com/5BCFldsIHxb42xs8lw9u0a",
                "https://chat.whatsapp.com/38qaOIIdLO20Lhyuz8iWAY",
                "https://chat.whatsapp.com/BucO04gZ3frKwMV8K1qzUl",
                "https://chat.whatsapp.com/JkLtvNmhzgSGi9yZEixJzq",
                "https://chat.whatsapp.com/43AaNpkr9eT42Mui0qmUMg",
                "https://chat.whatsapp.com/6ahDOVnSWSA8jCp0E5fyHS",
                "https://chat.whatsapp.com/75fRjkWgGP0DJnlwQ8wXhP",
                "https://chat.whatsapp.com/4kMy2dgWIP24tbIL1EFW19",
                "https://chat.whatsapp.com/09Wx39x05kF4reHLZ00mvC",
                "https://chat.whatsapp.com/0hBaqm4NmVcDSBMNnKX4Ka",
                "https://chat.whatsapp.com/Ghn33hdiBB8IHtOlyJmBfM",
                "https://chat.whatsapp.com/4c4DCAzRzM8CISlbdbXW0I",
                "https://chat.whatsapp.com/DSBBPjDbdSXAJC4bze1cur",
                "https://chat.whatsapp.com/8pQQi0occ3b3bjaKt7C7LA",
                "https://chat.whatsapp.com/ElzOx6J0NfNKd00qGoVYOe",
                "https://chat.whatsapp.com/GwmXUHNe9rt1yqh57qs7Be",
                "https://chat.whatsapp.com/Fv8gVCTE6hb8XPcN8ddya3",
                "https://chat.whatsapp.com/CEEZskZZzjAG9Kfrzn8owI",
                "https://chat.whatsapp.com/BniNQKO3QkWCYzhk5fUVCG",
                "https://chat.whatsapp.com/9EXjac8eKiJKlMdW6GscpR",
                "https://chat.whatsapp.com/B6LHz9R6zIRCkm0hj5ac8x",
                "https://chat.whatsapp.com/BqbXcm3coNbFTjAPAWY5es"
        };
//        Integer[] photos={R.drawable.cr7,R.drawable.messi,
//                R.drawable.torres,R.drawable.iniesta,
//                R.drawable.drogba,R.drawable.gerrard,
//                R.drawable.rooney,R.drawable.xavi};

        originalValues=new ArrayList<HashMap<String,Object>>();

        //temporary HashMap for populating the
        //Items in the ListView
        HashMap<String , Object> temp;

        //total number of rows in the ListView
        int noOfPlayers=names.length;

        //now populate the ArrayList players
        for(int i=0;i<noOfPlayers;i++)
        {
            temp=new HashMap<String, Object>();

            temp.put("name", names[i]);
            temp.put("team", teams[i]);
//            temp.put("photo", photos[i]);

            //add the row to the ArrayList
            originalValues.add(temp);
        }
        //searchResults=OriginalValues initially
        searchResults=new ArrayList<HashMap<String,Object>>(originalValues);
        final WhatsAppAdapter adapter=new WhatsAppAdapter(getContext(), R.layout.whatsapplistitem,searchResults);
        //finally,set the adapter to the default ListView
        playerListView.setAdapter(adapter);
        searchBox.addTextChangedListener(new TextWatcher() {

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //get the text in the EditText
                String searchString= searchBox.getText().toString();
                int textLength=searchString.length();
                searchResults.clear();

                for(int i=0;i<originalValues.size();i++)
                {
                    String playerName=originalValues.get(i).get("name").toString();
                    if(textLength<=playerName.length()){
                        //compare the String in EditText with Names in the ArrayList
                        if(searchString.equalsIgnoreCase(playerName.substring(0,textLength)))
                            searchResults.add(originalValues.get(i));
                    }
                }

                adapter.notifyDataSetChanged();
            }

            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {


            }

            public void afterTextChanged(Editable s) {


            }
        });


        playerListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        });




        return view;

    }
}
