package wilptt.dpallagolla.com.wilptimetable.Fragments;

import android.app.AlertDialog;
import android.app.ListFragment;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;


import org.json.JSONArray;
import org.json.JSONObject;


import java.util.ArrayList;

import wilptt.dpallagolla.com.wilptimetable.Adapters.myListAdapter;
import wilptt.dpallagolla.com.wilptimetable.R;
import wilptt.dpallagolla.com.wilptimetable.Models.TimeTable;

/**
 * Created by dpallagolla on 10/8/2017.
 */

public class myListFragment extends ListFragment implements AdapterView.OnItemClickListener{

    String response;

    public myListFragment() {

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    public void setSubjectDataToPreferences(String subjectData) {
        if(!subjectData.isEmpty()) {
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
            prefs.edit().putString("subjectData", subjectData).apply();
        }
    }

    public String getSubjectDataFromPreferences() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String subjectData = prefs.getString("subjectData", "");
        return subjectData;
    }

    public void setNotifications() {

        String subjectData = getSubjectDataFromPreferences();

        try {
            JSONArray courses = new JSONArray(subjectData);
            JSONObject obj;
            for (int i = 0; i < courses.length(); i++) {
                obj = courses.getJSONObject(i);
                TimeTable tt = new TimeTable();
                tt.courseCode = obj.getString("courseCode");
                tt.courseText = obj.getString("subjectString");
                tt.day = obj.getString("day");
                tt.time = obj.getString("time");
            }
        }
        catch (Exception e) {

        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.list_fragment, container, false);

        Bundle arguments = getArguments();

        response = arguments.getString("response");

        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        try {
            super.onActivityCreated(savedInstanceState);
//        ArrayAdapter adapter = ArrayAdapter.createFromResource(getActivity(),R.array.Planets, android.R.layout.simple_list_item_1)
            JSONArray courses = new JSONArray(response);
            ArrayList<TimeTable> times = new ArrayList<TimeTable>();

            JSONObject obj = new JSONObject();

            if(courses.length() == 0) {
                new AlertDialog.Builder(getActivity()).setTitle("Time Table not updated for this Subject!").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).show();

            }

            for(int i=0;i<courses.length();i++) {
                obj = courses.getJSONObject(i);
                TimeTable tt = new TimeTable();
                tt.courseCode = obj.getString("courseCode");
                tt.courseText = obj.getString("subjectString");
                tt.day = obj.getString("day");
                tt.time = obj.getString("time");
                times.add(tt);

            }

            TimeTable[] timeTables = new TimeTable[times.size()];
            times.toArray(timeTables);
            setSubjectDataToPreferences(response);
            setNotifications();
            myListAdapter adapter = new myListAdapter(getActivity(),timeTables);
            setListAdapter(adapter);
            getListView().setOnItemClickListener(this);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

}
