package wilptt.dpallagolla.com.wilptimetable.Adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.json.JSONArray;

import wilptt.dpallagolla.com.wilptimetable.R;
import wilptt.dpallagolla.com.wilptimetable.Models.TimeTable;

/**
 * Created by dpallagolla on 10/7/2017.
 */

public class myListAdapter extends ArrayAdapter<TimeTable> {

     Activity activity;
    Context context;
    JSONArray jsonArray;
    TimeTable[] timeTables;

    public myListAdapter(Context context, int resource) {
        super(context, resource);
    }

    public myListAdapter(Activity a, TimeTable[] times) {
        super(a.getApplicationContext(),-1, times);
        timeTables = times;
        context = a.getApplicationContext();
        activity = a;

    }

    @Override
        public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.rowlayout, parent, false);
//        TextView courseCode = (TextView) rowView.findViewById(R.id.textView2);
        TextView time = rowView.findViewById(R.id.textView3);
        TextView courseText = rowView.findViewById(R.id.textView4);
        TextView day = rowView.findViewById(R.id.textView5);

//        courseCode.setText(timeTables[position].courseCode);
        time.setText(timeTables[position].time);
        courseText.setText(timeTables[position].courseText);
        day.setText(timeTables[position].day);


        return rowView;

    }


}
