package wilptt.dpallagolla.com.wilptimetable.Activities;

import android.app.AlertDialog;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;

import android.widget.Spinner;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import wilptt.dpallagolla.com.wilptimetable.R;
import wilptt.dpallagolla.com.wilptimetable.Getters.TimeTableGetter;


public class MainActivity extends AppCompatActivity {

    public static boolean bisMockDataEnabled = true;

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(MainActivity.this.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AdRequest request = new AdRequest.Builder()
                .addTestDevice("33BE2250B43518CCDA7DE426D04EE232")
                .build();
//        AdRequest request = new AdRequest.Builder()
//                .build();

        AdView adView = (AdView) this.findViewById(R.id.adView);
        adView.loadAd(request);

        Spinner spinner1;

        spinner1 = (Spinner) findViewById(R.id.spinner1);
        try {
            spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    if(!isNetworkAvailable()) {

                        new AlertDialog.Builder(parent.getContext()).setTitle("No Internet Connection").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        }).show();

                        return;

                    }
                    String sCode = (String) parent.getItemAtPosition(position);

                    if (!sCode.contains("COURSE CODE")) {
                        String link = "https://wilptt-181505.appspot.com/?show=";
                        link = link + sCode;
                        try {
                            Log.i("subjectCode:", sCode);
                            new TimeTableGetter(MainActivity.this).execute(link);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.rate_app:
                final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);

                emailIntent.setType("plain/text");
                emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"pallagolla.dwarakesh@gmail.com"});
                emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "WILP Time Table Issue:");
                emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "");
                MainActivity.this.startActivity(Intent.createChooser(emailIntent, "Send mail..."));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
