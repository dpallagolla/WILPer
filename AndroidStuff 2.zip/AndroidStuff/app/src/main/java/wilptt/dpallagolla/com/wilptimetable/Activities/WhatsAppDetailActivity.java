package wilptt.dpallagolla.com.wilptimetable.Activities;


import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import wilptt.dpallagolla.com.wilptimetable.R;

/**
 * Created by deadpool on 21/12/17.
 */

public class WhatsAppDetailActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        super.onCreate(savedInstanceState);
        Bundle b = getIntent().getExtras();
        String sName = b.getString("name");
        String sLink = b.getString("link");
        String sDescription = b.getString("description");
        setContentView(R.layout.whatsappdetail);
        TextView t = findViewById(R.id.group_name);
        t.setText(sName);
        TextView t1 = findViewById(R.id.group_link);
//        t1.setMovementMethod(LinkMovementMethod.getInstance());
        t1.setText(sLink);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);

        AdRequest request = new AdRequest.Builder()
                .build();

        AdView adView = (AdView) findViewById(R.id.adView);
        adView.loadAd(request);

        getSupportActionBar().setTitle("WILPer");

        getSupportActionBar().setDisplayShowTitleEnabled(true);

//        android.app.ActionBar a = getActionBar();
//        ActionBar b1 = getSupportActionBar();
    }

}
