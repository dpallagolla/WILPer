package wilptt.dpallagolla.com.wilptimetable.Fragments;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import wilptt.dpallagolla.com.wilptimetable.R;
import wilptt.dpallagolla.com.wilptimetable.Getters.TimeTableGetter;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by deadpool on 16/12/17.
 */

public class TimeTableFragment extends Fragment {

    public static boolean bisMockDataEnabled = false;

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getActivity().getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public String getSubjectFromPreferences() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
        String subjectCode = prefs.getString("subjectCode", "");
        return subjectCode;
    }

    public void setSubjectToPreferences(String subjectCode) {
        if(!subjectCode.isEmpty()) {
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getActivity());
            prefs.edit().putString("subjectCode", subjectCode).apply();
        }
    }


    public void setSpinnerItem(String subjectCode, Spinner spinner) {
        spinner.setSelection(((ArrayAdapter<String>)spinner.getAdapter()).getPosition(subjectCode));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.activity_main, container, false);



//        AdRequest request = new AdRequest.Builder()
//                .addTestDevice("33BE2250B43518CCDA7DE426D04EE232")
//                .build();
        AdRequest request = new AdRequest.Builder()
                .build();

        AdView adView = (AdView) view.findViewById(R.id.adView);
        adView.loadAd(request);

        Spinner spinner1;

        spinner1 = (Spinner) view.findViewById(R.id.spinner1);

        String subjectCode = getSubjectFromPreferences();

        if(!subjectCode.isEmpty()) {
            setSpinnerItem(subjectCode,spinner1);
        }

        try {
            spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    if(!isNetworkAvailable()) {

                        new AlertDialog.Builder(parent.getContext()).setTitle("No Internet Connection").setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        }).show();

                        return;

                    }
                    String sCode = (String) parent.getItemAtPosition(position);

                    setSubjectToPreferences(sCode);

                    if (!sCode.contains("COURSE CODE")) {
                        String link = "https://wilptt-181505.appspot.com/?show=";
                        link = link + sCode;
                        try {
                            Log.i("subjectCode:", sCode);
                            new TimeTableGetter(getActivity()).execute(link);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }


        return view;


    }


}
