package wilptt.dpallagolla.com.wilptimetable.Models;

/**
 * Created by dpallagolla on 10/8/2017.
 */

public class TimeTable {

   public String courseCode;
   public String time;
   public String day;
   public String courseText;
}
