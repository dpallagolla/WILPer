package wilptt.dpallagolla.com.wilptimetable.Fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import wilptt.dpallagolla.com.wilptimetable.R;

/**
 * Created by deadpool on 26/12/17.
 */

public class SuggestImprovements extends Fragment {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_suggest_improvements, container, false);

        AdRequest request = new AdRequest.Builder()
                .addTestDevice("33BE2250B43518CCDA7DE426D04EE232")
                .build();
//        AdRequest request = new AdRequest.Builder()
//                .build();

        AdView adView = (AdView) view.findViewById(R.id.adView);
        adView.loadAd(request);

        return view;


    }


}
