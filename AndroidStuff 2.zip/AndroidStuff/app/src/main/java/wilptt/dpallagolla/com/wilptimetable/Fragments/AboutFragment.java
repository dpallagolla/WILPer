package wilptt.dpallagolla.com.wilptimetable.Fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import wilptt.dpallagolla.com.wilptimetable.R;


/**
 * Created by deadpool on 16/12/17.
 */

public class AboutFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_about, container, false);

//        AdRequest request = new AdRequest.Builder()
//                .addTestDevice("33BE2250B43518CCDA7DE426D04EE232")
//                .build();
        AdRequest request = new AdRequest.Builder()
                .build();

        AdView adView = (AdView) view.findViewById(R.id.adView);
        adView.loadAd(request);

        return view;


    }

}
