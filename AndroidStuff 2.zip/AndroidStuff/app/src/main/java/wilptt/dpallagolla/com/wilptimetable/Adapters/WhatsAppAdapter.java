package wilptt.dpallagolla.com.wilptimetable.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

import wilptt.dpallagolla.com.wilptimetable.R;
import wilptt.dpallagolla.com.wilptimetable.Activities.WhatsAppDetailActivity;

/**
 * Created by deadpool on 21/12/17.
 */

public class WhatsAppAdapter extends ArrayAdapter<HashMap<String, Object>> {

    Context context;
    ArrayList<HashMap<String, Object>> searchResults;
    public WhatsAppAdapter(Context context, int textViewResourceId,
                           ArrayList<HashMap<String, Object>> Strings) {

        //let android do the initializing :)
        super(context, textViewResourceId, Strings);
        this.context = context;
        this.searchResults = Strings;
    }


    //class for caching the views in a row
    private class ViewHolder {
        ImageView photo;
        TextView name, team;

    }

    ViewHolder viewHolder;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.whatsapplistitem, null);
            viewHolder = new ViewHolder();

            //cache the views
//            viewHolder.photo = (ImageView) convertView.findViewById(R.id.photo);
            viewHolder.name =  convertView.findViewById(R.id.name);
            viewHolder.team =  convertView.findViewById(R.id.team);

            //link the cached views to the convertview
            convertView.setTag(viewHolder);
            convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, WhatsAppDetailActivity.class);
                    TextView group_name = view.findViewById(R.id.name);
                    TextView group_link = view.findViewById(R.id.team);
//                    TextView group_description = view.findViewById(R.id.group_description);
                    String sgroup_name,sgroup_link,sgroup_description;
                    sgroup_name = group_name.getText().toString();
                    sgroup_link = group_link.getText().toString();
//                    sgroup_description = group_description.getText().toString();
                    intent.putExtra("name",sgroup_name);
                    intent.putExtra("link",sgroup_link);
//                    intent.putExtra("description",sgroup_description);
                    context.startActivity(intent);
                }
            });


        } else
            viewHolder = (ViewHolder) convertView.getTag();


//        int photoId = (Integer) searchResults.get(position).get("photo");

        //set the data to be displayed
//        viewHolder.photo.setImageDrawable(getResources().getDrawable(photoId));
        viewHolder.name.setText(searchResults.get(position).get("name").toString());
        viewHolder.team.setText(searchResults.get(position).get("team").toString());

        //return the view to be displayed
        return convertView;
    }
}